# QOL 0.0.1
[![Build Status](https://travis-ci.com/tmhuysen/QOL.svg?branch=develop)](https://travis-ci.com/tmhuysen/QOL)


Python Quality of Life package


[![numpy Dependency](https://img.shields.io/badge/numpy-1.16.2+-0d0d6d.svg)](http://www.numpy.org/)
[![python3.7 Dependency](https://img.shields.io/badge/python-3.7+-0d0d6d.svg)](http://www.numpy.org/)
